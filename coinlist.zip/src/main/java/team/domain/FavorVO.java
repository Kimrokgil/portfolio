package team.domain;

import lombok.Data;

@Data
public class FavorVO {

	private String u_id;
	private String symbol;
		
}
